import React, { createContext, useContext, useEffect, useState } from "react";
import socket from "../../utils/socket"; // make sure this exists

const GameContext = createContext();

export const GameProvider = ({ children }) => {
  const [roomId, setRoomId] = useState(null);
  const [players, setPlayers] = useState([]);
  const [myPlayerId, setMyPlayerId] = useState(null);
  const [currentTurn, setCurrentTurn] = useState(null);
  const [mode, setMode] = useState(null);

  const [playerPositions, setPlayerPositions] = useState({
    red: [0, 0, 0, 0],
    blue: [0, 0, 0, 0],
    green: [0, 0, 0, 0],
    yellow: [0, 0, 0, 0],
  });

  const [diceNumber, setDiceNumber] = useState(0);
  const [diceDisabled, setDiceDisabled] = useState(false);
  const [win, setWin] = useState([]);
  const [size, setSize] = useState({
    board: 1,
    dice: 1.2,
    playerBox: 1,
  });

  const rollDice = () => {
    if (!roomId || !myPlayerId) return;
    socket.emit("roll_dice", { roomId, playerId: myPlayerId });
    setDiceDisabled(true); // prevent double roll
  };

  // Handle dice result from server
  useEffect(() => {
    socket.on("dice_rolled", ({ playerId, value }) => {
      setDiceNumber(value);
      setDiceDisabled(false); // re-enable after result
      // optional: trigger movement logic here
    });

    return () => {
      socket.off("dice_rolled");
    };
  }, []);

  const nextTurn = () => {
    if (!players.length) return;
    setCurrentTurn((prev) => {
      const index = players.findIndex((p) => p.id === prev);
      const next = players[(index + 1) % players.length];
      return next?.id || null;
    });
  };

  return (
    <GameContext.Provider
      value={{
        roomId,
        setRoomId,
        players,
        setPlayers,
        myPlayerId,
        setMyPlayerId,
        currentTurn,
        setCurrentTurn,
        mode,
        setMode,

        playerPositions,
        setPlayerPositions,
        diceNumber,
        setDiceNumber,
        diceDisabled,
        setDiceDisabled,
        win,
        setWin,

        nextTurn,
        size,
        setSize,
        rollDice,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGameContext = () => useContext(GameContext);
