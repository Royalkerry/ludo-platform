import React, { useEffect, useRef, useState } from "react";
import { useGameContext } from "../context/GameContext";
import DiceRolled from "../utilities/DiceRolled";
import "../styles/Dice.css";
import rollSound from "../assets/roll.mp3";

const Dice = ({ canRoll }) => {
  const {
    rollDice,
    diceDisabled,
    setDiceDisabled,
    currentTurn,
    playerPositions,
    nextTurn,
    size,
    players,
    myPlayerId,
  } = useGameContext();

  const diceNumberValue = useRef(0);
  const [rotated, setRotated] = useState(false);
  const [diceStyle, setDiceStyle] = useState("hidden");
  const [allValues, setValues] = useState([1, 2, 3, 4, 5, 6]);

  const audio = new Audio(rollSound);
  const currentColor = players.find((p) => String(p.id) === String(currentTurn))?.color;

  const handleClick = () => {
    if (diceDisabled || !canRoll) return;

    audio.play();

    setTimeout(() => {
      setDiceStyle("visible");

      const number = Math.ceil(Math.random() * 6);
      diceNumberValue.current = number;

      setValues((prev) => {
        const updated = [...prev];
        if (number >= 1 && number <= 6) {
          updated[number - 1] = 2;
        }
        return updated;
      });

      setDiceDisabled(true);
    }, 100);

    setRotated(true);

    setTimeout(() => {
      setRotated(false);
      audio.pause();
      audio.currentTime = 0;
    }, 1000);

    setTimeout(() => setDiceStyle("hidden"), 800);
  };

  useEffect(() => {
    if (!currentColor || !playerPositions[currentColor]) return;
    const diceNumber = diceNumberValue.current;

    if (diceNumber === 0) return;

    DiceRolled(diceNumberValue, nextTurn, currentColor, playerPositions, setDiceDisabled);

    if (diceNumber === 6 || playerPositions[currentColor]?.some((pos) => pos !== 0)) {
      setDiceDisabled(true);
    } else {
      setTimeout(() => {
        diceNumberValue.current = 0;
        nextTurn();
        setDiceDisabled(false);
      }, 1500);
    }
  }, [playerPositions, nextTurn, setDiceDisabled, currentColor]);

  return (
    <div id="dice" style={{ transform: `scale(${size?.dice || 1.2})` }}>
      <div
        className={`dice ${rotated ? "rotate" : ""} ${
          diceDisabled || !canRoll ? "pointer-events-none opacity-50" : "cursor-pointer"
        }`}
        onClick={handleClick}
        style={{ overflow: diceStyle }}
      >
        {allValues.map((val, idx) => (
          <div
            key={idx}
            className={`face ${["top", "front", "left", "back", "right", "bottom"][idx]} ${
              idx % 2 === 0 ? "shadow-on" : ""
            }`}
          >
            <div className={`inner-face face${val}`}>
              {idx === 3 && diceNumberValue.current !== 0 ? (
                Array(diceNumberValue.current)
                  .fill()
                  .map((_, i) => <span key={i} className="dot" />)
              ) : idx === 3 ? (
                <span className="dice-initial-face">ROLL</span>
              ) : (
                Array(val)
                  .fill()
                  .map((_, i) => <span key={i} className="dot" />)
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dice;
