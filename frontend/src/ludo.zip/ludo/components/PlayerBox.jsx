import React from 'react';
import Dice from "./Dice";
import { useGameContext } from "../context/GameContext";

const positionClass = {
  "top-left": "absolute top-[80px] left-[10px] z-50 md:top-[100px] md:left-[250px]",
  "top-right": "absolute top-[80px] right-[10px] z-50 md:top-[100px] md:right-[250px]",
  "bottom-left": "absolute bottom-[80px] left-[10px] z-50 md:bottom-[100px] md:left-[250px]",
  "bottom-right": "absolute bottom-[80px] right-[10px] z-50 md:bottom-[100px] md:right-[250px]",
};

const PlayerBox = ({ player, position }) => {
  const { currentTurn, myPlayerId } = useGameContext();

  const isCurrentPlayer = String(player?.id) === String(currentTurn);
  const isMyTurn = isCurrentPlayer && String(player?.id) === String(myPlayerId);
  const positionStyle = positionClass[position] || "";

  return (
    <div className={`${positionStyle} bg-white rounded-lg shadow p-3 w-[120px] text-center`}>
      <div className="text-3xl mb-1">{player?.avatar || "👤"}</div>
      <div className="text-sm text-black font-semibold truncate w-full">
        {player?.name || "Player"}
      </div>

      {/* Show dice only to the player whose turn it is */}
      {isCurrentPlayer && (
        <div className="mt-2">
          <Dice canRoll={isMyTurn} />
        </div>
      )}
    </div>
  );
};

export default PlayerBox;
